module.exports.Heroes = require('./Heroes.js');
module.exports.Potg = require('./potg.js');
module.exports.User = require('./User.js');
